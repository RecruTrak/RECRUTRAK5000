<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$config = array(
	'protocol' => 'smtp',
	'smtp_host' => 'ssl://smtp.googlemail.com',
	'smtp_port' => 465,
	'smtp_user' => 'recrutrak5000@gmail.com',
	'smtp_pass' => 'CS495-001',
	'starttls' => true,
	'newline' => "\r\n"
);