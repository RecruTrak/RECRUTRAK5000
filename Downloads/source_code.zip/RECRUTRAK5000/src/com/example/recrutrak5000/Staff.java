package com.example.recrutrak5000;

import java.io.Serializable;

public class Staff implements Serializable {
	private static final long serialVersionUID = 1L;
	public int id;
	public Department department;
	public Request[] requests;
	public Meeting[] meetings;
}
